//console.log("hello web!");
let sayHello = (name) => `Hello, ${name}!`;
console.log(sayHello(process.argv[2]));
