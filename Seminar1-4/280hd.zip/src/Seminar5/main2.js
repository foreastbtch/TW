import { nrZile, procentDinAn } from "./modul.js";

let x = 301;

console.log(procentDinAn(301));
