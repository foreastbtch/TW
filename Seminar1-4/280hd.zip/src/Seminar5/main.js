// import { pi as someValue, Sum, Product } from "./math.js";
import * as Math from "./math.js";
// console.log(someValue);
// console.log(Sum(1, 2));
// console.log(Product(2, 3));
console.log(Math.pi);
console.log(Math.Sum(1, 2));
console.log(Math.Product(2, 3));
