const a = 365;

const f = (x) => {
  return (x / 365) * 100;
};

export { a as nrZile, f as procentDinAn };
